---
name: Báo cáo lỗi
about: Tạo báo cáo lỗi để giúp chúng tôi cải thiện ứng dụng
title: "[BUG] "
labels: bug
assignees: ''
---

**Mô tả lỗi**
Mô tả ngắn gọn và rõ ràng về lỗi.

**Các bước tái tạo lỗi**
Các bước để tái tạo lỗi:
1. Đi đến '...'
2. Nhấp vào '....'
3. Cuộn xuống '....'
4. Thấy lỗi

**Hành vi mong đợi**
Mô tả rõ ràng về những gì bạn mong đợi sẽ xảy ra.

**Ảnh chụp màn hình**
Nếu có thể, hãy thêm ảnh chụp màn hình để giúp giải thích vấn đề của bạn.

**Môi trường:**
 - Thiết bị: [ví dụ: Desktop, iPhone6]
 - Hệ điều hành: [ví dụ: iOS, Windows]
 - Trình duyệt: [ví dụ: chrome, safari]
 - Phiên bản: [ví dụ: 22]

**Thông tin bổ sung**
Thêm bất kỳ thông tin bổ sung nào khác về vấn đề ở đây.