---
name: Yêu cầu tính năng mới
about: Đề xuất ý tưởng cho dự án
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

**Yêu cầu tính năng của bạn có liên quan đến vấn đề nào không? Vui lòng mô tả.**
Mô tả ngắn gọn và rõ ràng về vấn đề (ví dụ: Tôi luôn cảm thấy khó chịu khi [...]). Nếu có đề xuất giải pháp, vui lòng nêu chi tiết.

**Mô tả giải pháp bạn muốn**
Mô tả rõ ràng và ngắn gọn về những gì bạn muốn xảy ra.

**Mô tả các giải pháp thay thế bạn đã xem xét**
Mô tả rõ ràng và ngắn gọn về bất kỳ giải pháp hoặc tính năng thay thế nào bạn đã xem xét.

**Tại sao tính năng này quan trọng?**
Giải thích tại sao tính năng này sẽ cải thiện trải nghiệm người dùng hoặc giá trị của dự án.

**Thông tin bổ sung**
Thêm bất kỳ thông tin hoặc ảnh chụp màn hình nào khác về yêu cầu tính năng ở đây.